﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            var fileResult = openFileDialog1.ShowDialog();
            if (fileResult == DialogResult.OK)
            {
                using (var fileStream = openFileDialog1.OpenFile())
                {
                    XmlSerializer mySerializer = new XmlSerializer(typeof(ContactLead));
                    ContactLead contactLead = (ContactLead)mySerializer.Deserialize(fileStream);
                    textBoxName.Text = contactLead.Name;
                    textBoxEmail.Text = contactLead.Email;
                    textBoxAddress.Text = contactLead.Address;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ContactLead contactLead = new ContactLead();
            contactLead.Name = this.textBoxName.Text;
            contactLead.Email = this.textBoxName.Text;
            contactLead.Address = this.textBoxAddress.Text;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            var fileResult = saveFileDialog1.ShowDialog();
            XmlSerializer serializer = new XmlSerializer(typeof(ContactLead));

            TextWriter writer = new StreamWriter(saveFileDialog1.FileName);

            serializer.Serialize(writer, contactLead);

            writer.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            textBoxEmail.Clear();
            textBoxAddress.Clear();
        }
    }
}
    

